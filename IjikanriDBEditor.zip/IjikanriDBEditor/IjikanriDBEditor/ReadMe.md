# クラスの役割

* IjikanriContext
EntityFrameworkでデータベースにアクセスするクラス。接続情報とテーブル名くらいしかない。
* NamTicketAccessor
EntityFrameworkでデータベースからレコードをNamTicketのインスタンスとして取得するクラス。更新、削除もできる。

* NamTicket
データベースの１レコードに対応するクラス。EntityFrameworkでレコードと紐づけしてる。

* NamTicketModel
NamTicketを保持し、チェック処理を実装するクラス。NamTicketにチェック処理を持たせるとEntityFramework的に微妙かと思い
NamTicketをラップするイメージでクラスにした。

* MainWindowViewModel
プロパティNamTicketVMsでNamTicketModelのリストを持つ。コンボボックスの選択しの情報もここで保持する。

* MainWindow
実行すると表示されるウィンドウ自体を表すクラス。
ウィンドウの中に検索ページと詳細ページを表示するようになっているので、ウィンドウ自体にはとくに処理はない。

* App.xaml
このアプリケーションのエントリーポイントになるクラス。

* TicketSearchPage
検索画面のページ。検索条件を設定してデータベースを検索し、条件にあったレコードを表で表示する。

* TicketDetailPage
検索画面で１レコードを選択してダブルクリックしたときに、１レコードの明細を表示する画面。

* TimeConverter
開始日などのカレンダーで日付を選択する部品が期待する日付の型と、データベースで保持している日付の型の違いを吸収するクラス。
表示時と設定時に変換してるだけ。
* DateToStringConverter
データベースで保持している日付の型を表で表示するために文字列に変換するクラス。

* EnumerableExtensions
データベースの検索条件をオブジェクトとして表現するクラス。
ネットからコピーしてきたので半分くらいしか理解してないけど...

## データの持ち方
### NamTicketクラスとNamTicketModelクラス
* テーブルの１レコードに対応するクラスがNamTicket。
* NamTicketをテーブルのレコードに対応するオブジェクトにとどめたかったので、NamTicketをラップし、業務ロジックを追加したのがNamTicketModelクラス。
* NamTicketAccessor.GetNamTicketsメソッドが返すのが、NamTicketのList。
* MainWindowViewModel.xxxメソッドでNamTicketAccessor.GetNamTicketsメソッドを呼び出しNamTicketのListを取得して、取得した全レコード分のNamTicketからNamTicketModelを生成し、NamTicketModelのリストを保持する（namTicketVMs。プロパティだとNamTicketVMs）
### データ取得の動き
* TicketSearchPage.xaml.csのチケット検索ボタンをクリックするとMainWindowViewModel.xxx()を呼び出し、DataGridのアイテムソースにMainWindowViewModel.NamTicketVMsを設定し、取得した結果をDataGridに表示している。
### 検索画面から明細画面への遷移
* 検索画面TicketSearchPage.xamlのDataGridのDoubleTappedイベントで明細画面TicketDetailPageへ遷移し、その時引数で自分自身を渡す。
* 明細画面側で遷移したときのイベントOnNavigatedToで、引数のTicketSearchPageのGetDataGridSelectedItemメソッドから、検索画面でダブルクリックした対象のNamTicketModelを取得しTicketDetailPageのSelectedTicketプロパティに保持する。
* 明細画面ではこのプロパティでバインドしている。こんな感じSelectedTicket.TicketCode。
### 明細画面保存時の動き
* 保存ボタンのクリックイベントでOnSaveClickedメソッドを呼び出す。


##
## App  
### フィールド
* Window? m_window  
### メソッド
* OnLaunched  
  * 起動時に呼び出されるメソッド。
  * MainWindowを生成してm_windowに設定。
  * Frameを生成してTicketSearchPageに遷移してFrameをWindowのコンテンツに設定してる。

## MainWindow
  空のWindow。
### コンストラクタ
* SetWindowSizeの呼び出し。
### メソッド
* SetWindowSize
  * サイズの変更のみ実行。

## TicketSearchPage  
検索画面。
### プロパティ
* MainWindowViewModel ViewModel
MainWindowViewModelを保持している。
### コンストラクタ
MainWindowViewModelをインスタンス化してViewModelプロパティに設定する。
### メソッド
* OnSearchClickedメソッド  
  * MainWindowViewModelのxxxメソッドを呼び出す  
  * WinUI3DataGrid.ItemsSourceにMainWindowViewModelのNamTicketVMsを設定して、検索結果を表示する。
* DataGridDoubleTappedメソッド
  * DataGridをダブルクリックしたときに起動する。  
  * 自分自身を引数に、TicketDetailPageに遷移する、
* GetDataGridSelectedItemメソッド
  * DataGridのSelectedItemsの最初の要素を返す   

  -----------------------
  検索
  条件を指定して検索できるようにしたところまで。
  正しく検索出来てるかを見る。