
using Microsoft.UI.Xaml.Data;
namespace IjikanriDBEditor;
public class TimeConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, string language)
    {
        LogWriter.WriteLog("Debug", "TimeConverter Convert START:" + value.ToString());
        return new DateTimeOffset(((DateTime)value).ToUniversalTime());
    }

    public object ConvertBack(object value, Type targetType, object parameter, string language)
    {
        LogWriter.WriteLog("Debug", "TimeConverter ConvertBack START Value:" + value.ToString() + " Type:" + targetType.ToString());
        DateTime returnValue = new();
        if (value.GetType() == typeof(DateTime)) 
        {
            returnValue = (DateTime)value;
        }
        else
        {
            returnValue = ((DateTimeOffset)value).DateTime;
        }
        return returnValue;
    }
}
        