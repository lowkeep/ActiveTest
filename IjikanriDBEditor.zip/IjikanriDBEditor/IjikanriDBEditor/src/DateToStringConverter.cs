using System.Diagnostics;
using System.Runtime.CompilerServices;
using log4net;
using Microsoft.UI.Xaml.Data;
namespace IjikanriDBEditor
{
    public class DateToStringConverter : IValueConverter
    {
        
        public DateToStringConverter()
        {
        }

        public object Convert(object value, Type targetType, object parameter, string language)
        {
            LogWriter.WriteLog("Debug", "DateToStringConverter Convert START");
            DateTime arg = (DateTime)value;
            string valueType = value.GetType().ToString();
            string message;
            if (parameter == null)
            {
                message = "null";
            }
            else 
            {
                message = parameter.ToString();
            }
            LogWriter.WriteLog("Debug", " value:" + value.ToString() + " valueType:" + valueType + "targetType:" + targetType.ToString());
            LogWriter.WriteLog("Debug", " parameter:" + message + " language:" + language + " result:" + arg.ToString("yyyy/MM/dd"));
            LogWriter.WriteLog("Debug", "DateToStringConverter Convert END");
            return arg.ToString("yyyy/MM/dd");
        }

        public object ConvertBack(object value, Type targetType, object parameter, string language)
        {
            LogWriter.WriteLog("Debug", "ConvertBack START value:" + value.ToString());
            string valueType = value.GetType().ToString();
            LogWriter.WriteLog("Debug", " valueType:" + valueType);
            LogWriter.WriteLog("Debug", " targetType:" + targetType.ToString());
            string message;
            if (parameter == null)
            {
                message = "null";
            }
            else 
            {
                message = parameter.ToString();
            }
            LogWriter.WriteLog("Debug", "ConvertBack END parameter:" + message + " language:" + language + " result:" + DateTime.Parse(value.ToString()).ToString("yyyy/MM/dd"));
            DateTime result = DateTime.Parse(value.ToString());
            return result;
        }
     }
}