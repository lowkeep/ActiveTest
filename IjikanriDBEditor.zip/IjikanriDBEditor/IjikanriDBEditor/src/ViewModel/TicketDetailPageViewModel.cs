namespace IjikanriDBEditor;

using IjikanriDBEditor.Entiry;
public class TicketDetailPageViewModel
{
    private NamTicket formValue;
    public NamTicket FormValue{
        get => this.formValue;
        set => this.formValue = value;
    }    

    public TicketDetailPageViewModel()
    {
        this.FormValue = new NamTicket();
    }
    public TicketDetailPageViewModel(NamTicket value)
    {
        this.FormValue = value.GetClone();
    }


}