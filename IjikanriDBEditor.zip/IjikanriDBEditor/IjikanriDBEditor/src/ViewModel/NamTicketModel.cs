using System.Collections;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using IjikanriDBEditor.Entiry;

namespace IjikanriDBEditor;
public class NamTicketModel : IEditableObject, INotifyDataErrorInfo, INotifyPropertyChanged
{
    /// <summary>テーブルと紐づくNamTicket</summary>
    private NamTicket ticket;
    /// <summary>エラー情報を保持するディクショナリ</summary>
    private Dictionary<string, HashSet<string>> errorDictionary;
    /// <summary>修正前チケットコード</summary>
    private string originalTicketCode;
    /// <summary>修正前チケット</summary>
    private NamTicket? originalTicke;

#region NamTicketをラップするプロパティ定義
    /// <summary>チケットコード</summary>
    public string TicketCode
    {
        get => this.ticket.TicketCode;
        set
        {
            LogWriter.WriteLog("Debug","TicketCode #####SET##### value:" + value + " originalTicketCode:" + this.originalTicketCode);
            // 修正前チケットコードが未設定かつ、
            // 設定しようとしているチケットコードがNULLでも空でもないか判定
            /*
            if (string.IsNullOrEmpty(this.originalTicketCode) == true && string.IsNullOrEmpty(value) == false)
            {
            */
            if (string.IsNullOrEmpty(value) == false && value.Equals(this.originalTicketCode) == false)
            {
                // 条件を満たすとき、最初に設定するチケットコードと判断し、修正前チケットコードとして保持する
                //this.originalTicketCode = value;
                //LogWriter.WriteLog("Debug","originalTicketCode #####SET#####" + value);
                // チケットコード変更前のチケットを取得しておく
                NamTicket tempTicket = this.ticket.GetClone();
                // トラッキングされているもともとのチケットをoriginalTickeに設定
                //this.originalTicke = this.ticket;
                // クローンしたチケットをこのNamTicketModelでラップするチケットに設定
                this.ticket = tempTicket;
            }
            // 変更後のチケットコードを設定
            this.ticket.TicketCode = value;
        }
    }

    /// <summary>開始日</summary>
    public DateTime KaishiBi
    {
        get => this.ticket.KaishiBi;
        set => this.ticket.KaishiBi = value;
    }

    /// <summary>ご依頼部署</summary>
    public string GoriraiBusho
    {
        get => this.ticket.GoriraiBusho;
        set => this.ticket.GoriraiBusho = value;
    }

    /// <summary>ご担当者</summary>
    public string GotantouSha
    {
        get => this.ticket.GotantouSha;
        set => this.ticket.GotantouSha = value;
    }

    /// <summary>システム名</summary>
    public string SystemMei
    {
        get => this.ticket.SystemMei;
        set => this.ticket.SystemMei = value;
    }

    /// <summary>分類</summary>
    public string Bunrui
    {
        get => this.ticket.Bunrui;
        set => this.ticket.Bunrui = value;
    }

    /// <summary>件名</summary>
    public string Kenmei
    {
        get => this.ticket.Kenmei;
        set => this.ticket.Kenmei = value;
    }

    /// <summary>概要</summary>
    public string Gaiyo
    {
        get => this.ticket.Gaiyo;
        set => this.ticket.Gaiyo = value;
    }

    /// <summary>予定時間</summary>
    public string YoteiJikan
    {
        get => this.ticket.YoteiJikan;
        set => this.ticket.YoteiJikan = value;
    }

    /// <summary>起票者</summary>
    public string KihyoSha
    {
        get => this.ticket.KihyoSha;
        set
        {
            LogWriter.WriteLog("Debug","KihyoSha SET value:" + value);
            if (string.Compare("高山", value) == 0) 
            {
                this.AddErrorMessage("KihyoSha","えらーとする");
            }
            else
            {
                this.ClearErrorMessage("KihyoSha");
            }
            this.ticket.KihyoSha = value;
            LogWriter.WriteLog("Debug","KihyoSha SET END#####");
        }
    }

    /// <summary>起票日</summary>
    public DateTime KihyoBi
    {
        get => this.ticket.KihyoBi;
        set
        {
            LogWriter.WriteLog("Debug","KihyoBi SET value:" + value);
            if (value.Year == 2023 && value.Month == 9 && value.Day == 11)
            {
                this.AddErrorMessage("KihyoBi","9.11えらーとする");
                this.OnErrorsChanged(nameof(KihyoBi));
            }
            else
            {
                this.ClearErrorMessage("KihyoBi");
                this.OnErrorsChanged(nameof(KihyoBi));
            }
            this.ticket.KihyoBi = value;
            RaisePropertyChanged(nameof(KihyoBi));
            //RaisePropertyChanged(nameof(KihyoBi));
            LogWriter.WriteLog("Debug","KihyoBi SET END#####");
        }
    }

    /// <summary>申し送り事項</summary>
    public string MoshiokuriJiko
    {
        get => this.ticket.MoshiokuriJiko;
        set => this.ticket.MoshiokuriJiko = value;
    }

    /// <summary>作業日</summary>
    public DateTime SagyoBi
    {
        get => this.ticket.SagyoBi;
        set => this.ticket.SagyoBi = value;
    }

    /// <summary>状況</summary>
    public string Jokyo
    {
        get => this.ticket.Jokyo;
        set
        {
            LogWriter.WriteLog("Debug","Jokyo SET ##### value:" + value);
             this.ticket.Jokyo = value;
            LogWriter.WriteLog("Debug","Jokyo SET ##### this.ticket.Jokyo:" + this.ticket.Jokyo);
        }
    }

    /// <summary>担当１</summary>
    public string Tanto1
    {
        get => this.ticket.Tanto1;
        set => this.ticket.Tanto1 = value;
    }

    /// <summary>担当２</summary>
    public string Tanto2
    {
        get => this.ticket.Tanto2;
        set => this.ticket.Tanto2 = value;
    }
#endregion NamTicketテーブルの定義

#region ##### INotifyDataErrorInfoのプロパティ実装 #####
    bool INotifyDataErrorInfo.HasErrors
    {
        get
        {
            bool result = (this.errorDictionary.Count > 0);
            LogWriter.WriteLog("Debug","HasErrors GET result:" + result);
            return result;
        }
    }
#endregion
    /// <summary>入力エラーが発生したときに、エラーメッセージを追加する。</summary>
    /// <param name="name">入力エラーが発生したプロパティ名</param>
    /// <param name="message">入力エラーのエラーメッセージ</param>
    private void AddErrorMessage(string name, string message)
    {
        LogWriter.WriteLog("Debug","AddErrorMessage ##START## name:" + name + " message:" + message);
        if (this.errorDictionary.ContainsKey(name) == false) 
        {
            this.errorDictionary[name] = new HashSet<string>();
        }
        HashSet<string> targetSet = this.errorDictionary[name];
        targetSet.Add(message);
        //this.OnErrorsChanged(name);
        LogWriter.WriteLog("Debug","AddErrorMessage ##END## name:" + name + " targetSet.Count:" + targetSet.Count);
    }
    /// <summary>入力エラーが解消したときに、エラーメッセージを削除する。</summary>
    /// <param name="name">入力エラーが解消したプロパティ名</param>
    private void ClearErrorMessage(string name)
    {
        LogWriter.WriteLog("Debug","ClearErrorMessage ##START##   name:" + name);
        if (this.errorDictionary.ContainsKey(name) == true) 
        {
            this.errorDictionary.Remove(name);
            //this.OnErrorsChanged(name);
        }
        LogWriter.WriteLog("Debug","ClearErrorMessage ##END##");
    }

    /// <summary>NamTicketModelのデフォルトコンストラクタ。空のNamTicketをラップする。</summary>
    public NamTicketModel() 
    {
        // ロガーのインスタンスの取得
        LogWriter.WriteLog("Debug","コンストラクタ");
        this.errorDictionary  = new();
        this.ticket = new NamTicket();
        this.originalTicke = null;
        this.originalTicketCode = string.Empty;
        TicketCode = "";
        KaishiBi = new DateTime(2023,1,1);
        GoriraiBusho = "";
        GotantouSha = "";
        SystemMei = "";
        Bunrui = "";
        Kenmei = "";
        Gaiyo = "";
        YoteiJikan = "";
        KihyoSha = "";
        KihyoBi = new DateTime(2023,1,1);
        MoshiokuriJiko = "";
        SagyoBi = new DateTime(2023,1,1);
        Jokyo = "";
        Tanto1 = "";
        Tanto2 = "";
    }



    /// <summary>
    /// NamTicketに入力チェックの処理を追加したNamTicketModelのコンストラクタ。
    /// </summary>
    /// <param name="ticket">管理対象のNamTicket</param>
    public NamTicketModel(NamTicket ticket) : this()
    {
        LogWriter.WriteLog("Debug", "NamTicketModelコンストラクタ target TicketCode:" + ticket.TicketCode );      
        this.ticket = ticket;
        // チケットコードが変更された時のために、変更前のチケットとチケットコードを保存しておく
        this.originalTicke = this.ticket;
        this.originalTicketCode = this.ticket.TicketCode;
        this.errorDictionary = new Dictionary<string, HashSet<string>>();
    }

    /// <summary>NamTicketModelがラップするNamTicketを返却する。</summary>
    /// <returns>NamTicketModelがラップするNamTicket</returns>
    public NamTicket GetNamTicket()
    {
        return this.ticket;
    }
    /// <summary>NamTicketModelがラップするNamTicketのオリジナルを返却する。</summary>
    /// <returns>NamTicketModelがラップするオリジナルのNamTicket</returns>
    public NamTicket? GetOriginalNamTicket()
    {
        return this.originalTicke;
    }

    public virtual bool HasTicketCodeChanged()
    {
        bool result = false;
        if (TicketCode.Equals(originalTicketCode) == false)
        {
            result = true;
        }
        return result;
    }

#region ##### INotifyDataErrorInfoのイベント #####
    public event EventHandler<DataErrorsChangedEventArgs>? ErrorsChanged;

    private void OnErrorsChanged(string propertyName)
    {
        var handler = this.ErrorsChanged;
        if (handler != null)
        {
            handler(this, new DataErrorsChangedEventArgs(propertyName));
        }
    }

#endregion
#region ##### INotifyPropertyChangedのイベント #####
    public event PropertyChangedEventHandler? PropertyChanged;
    private void RaisePropertyChanged([CallerMemberName]string propertyName = null)
        => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
#endregion

#region ##### IEditableObjectのメソッド実装 #####
    void IEditableObject.BeginEdit()
    {
        LogWriter.WriteLog("Debug", "BeginEdit TicketCode:" + this.ticket.TicketCode );      
    }

    void IEditableObject.CancelEdit()
    {
        LogWriter.WriteLog("Debug", "CancelEdit TicketCode:" + this.ticket.TicketCode );      
    }

    void IEditableObject.EndEdit()
    {
        LogWriter.WriteLog("Debug", "EndEdit TicketCode:" + this.ticket.TicketCode );      
    }
#endregion

#region ##### INotifyDataErrorInfoのメソッド実装 #####
    IEnumerable INotifyDataErrorInfo.GetErrors(string? propertyName)
    {
        LogWriter.WriteLog("Debug", "GetErrors target TicketCode:" + this.ticket.TicketCode + " propertyName:" + propertyName );
        // キーを空文字で初期化
        string key = string.Empty;
        // 引数のプロパティ名が空かNULLであるか判定
        if (string.IsNullOrEmpty(propertyName) == false)
        {
            // 空かNULL以外の場合、引数のプロパティ名をキーに設定
            key = propertyName;
        }
        // 戻り値の宣言
        IEnumerable result;
        // キーがディクショナリに存在するか判定
        if (this.errorDictionary.ContainsKey(key) == true) 
        {
            // 存在する場合、ディクショナリから取得
            result = this.errorDictionary[key];
        }
        else
        {
            // 戻り値を空のHashSetで初期化
            result = Enumerable.Empty<IEnumerable>();
        }
        LogWriter.WriteLog("Debug", "GetErrors key:" + key + " ContainsKey:" + this.errorDictionary.ContainsKey(key));
        // 戻り値を返却
        return result;
    }
 #endregion

}