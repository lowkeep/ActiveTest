using System.Collections;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using IjikanriDBEditor.Entiry;
using Microsoft.UI.Xaml.Controls;

namespace IjikanriDBEditor;
public class MainWindowViewModel : INotifyPropertyChanged
{
    public DateTimeOffset? KaishibiFrom {get; set;}
    public DateTimeOffset? KaishibiTo {get; set;}
    public string  SystemMei {get; set;}
    public string  Kihyousha {get; set;}
    public string  SearchKeyword {get; set;}

    public Func<string, string, bool, Task<ContentDialogResult>>  ShowDialogFunc { get; set; }
    


    /// <summary>システムグループに表示するリスト</summary>
    public List<string> SystemGroupNames { get; set; }
    /// <summary>システム名に表示するリスト</summary>
    public List<string> SystemNames { get; set; }
    /// <summary>ご担当者名に表示するリスト</summary>
    public List<string> GotantouShaNames { get; set; }
    /// <summary>起票者・NRI担当に表示するリスト</summary>
    public List<string> NRITantouNames { get; set; }
    /// <summary>ご依頼部署名に表示するリスト</summary>
    public List<string> GoiraiBushoNames { get; set; }
    /// <summary>分類に表示するリスト</summary>
    public List<string> BunruiNames { get; set; }
    
    private List<NamTicketModel> namTicketVMs;
    public List<NamTicketModel> NamTicketVMs
    {
        get
        {
            return namTicketVMs;
        }
        set
        {
            this.namTicketVMs = value;
            this.RaisePropertyChanged();
        }
    }

    private NamTicketAccessor accessor;
    private Window win;
    public void setWindow(Window target)
    {
        this.win = target;
    }

    public ICommand SerchTicketCommand { get; }
    public ICommand DeleteTicketCommand { get; }

#region ##### INotifyPropertyChangedのイベント #####
    public event PropertyChangedEventHandler? PropertyChanged;
    private void RaisePropertyChanged([CallerMemberName]string propertyName = null)
    {
        LogWriter.WriteLog("Debug", "RaisePropertyChanged propertyName:" + propertyName);
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }
#endregion


    public MainWindowViewModel() 
    {
        LogWriter.WriteLog("Debug", "MainWindowViewModel コンストラクタ");
        // Accessorのインスタンス化
        this.accessor = new NamTicketAccessor();
        // コンボボックス表示用リストの初期化
        this.InitializeSystemGroupNameList();
        this.InitializeSystemList();
        this.InitializeGotantouShaNameList();
        this.InitializeNRITantouNameList();
        this.InitializeGoiraiBushoNameList();
        this.InitializeBunruiNameList();
        this.SerchTicketCommand = new RelayCommand(test);
        this.DeleteTicketCommand = new RelayCommand<IList>(deltest);

        // 開始日の初期値設定
        this.SetKaishibi();
    }
    private protected virtual void test()
    {
        LogWriter.WriteLog("Debug", "test");
        LogWriter.WriteLog("Debug", "KaishibiFrom:" + this.KaishibiFrom.ToString());
        LogWriter.WriteLog("Debug", "KaishibiTo:" + this.KaishibiTo.ToString());
        LogWriter.WriteLog("Debug", "SystemMei:" + this.SystemMei);
        LogWriter.WriteLog("Debug", "Kihyousha:" + this.Kihyousha);
        if (this.KaishibiFrom.HasValue == false || this.KaishibiTo.HasValue == false)
        {
            LogWriter.WriteLog("Debug", "検索条件の開始日Fromまたは開始日ToがNULLです。");
            throw new ArgumentNullException("検索条件の開始日Fromまたは開始日ToがNULLです。");
        }
        
        this.SearchNamTicketsAndSetResultToGrid(
            this.KaishibiFrom.Value.DateTime,
            this.KaishibiTo.Value.DateTime,
            "",
            this.SystemMei,
            "",
            this.Kihyousha,
            "",
            this.SearchKeyword
        );
    }   
    private protected virtual async void deltest(IList target)
    {
        LogWriter.WriteLog("Debug", "deltest ##### 開始 #####");
        //IList<NamTicketModel> list = (IList<NamTicketModel>)target;
        // メッセージに表示する用のチケットコードを格納する文字列
        string messageTicketCode = "";
        foreach (NamTicketModel ticketModel in target) {
            messageTicketCode = messageTicketCode + "チケットコード：" + ticketModel.TicketCode + "\n";
        }
        messageTicketCode = messageTicketCode + "このチケットを削除します。よろしいですか？";
        ContentDialogResult result = await this.ShowDialogFunc("削除確認", messageTicketCode, true);
        LogWriter.WriteLog("Debug", "ShowDialogFunc result:" + result.ToString());
        if (result == ContentDialogResult.Primary)
        {

            //
            try 
            {
                foreach (NamTicketModel ticketModel in target) {
                    LogWriter.WriteLog("Debug", "SELECTED ticketcode:" + ticketModel.TicketCode);
                    //object item = SelectedItem;
                    this.accessor.DeleteRecord(ticketModel.GetNamTicket());
                }
            }
            catch (Exception e)
            {
                LogWriter.WriteLog("Debug", "削除処理で例外発生:" + e.ToString());
                LogWriter.WriteLog("Debug", "削除処理で例外発生 Message:" + e.Message);
                LogWriter.WriteLog("Debug", "削除処理で例外発生 StackTrace:" + e.StackTrace);
            }
            // 削除が終わったら検索を呼びなおす
            this.test();

        }
        LogWriter.WriteLog("Debug", "deltest ##### 終了 #####");
    }
    #region リスト初期化処理
    /// <summary>システムグループのコンボボックスに表示するリストの設定</summary>
    private protected virtual void InitializeSystemGroupNameList()
    {
        this.SystemGroupNames = new List<string>
        {
            "投信周辺",
            "顧問周辺",
            "SBA"
        };
    }
    /// <summary>システム名のコンボボックスに表示するリストの設定</summary>
    private protected virtual void InitializeSystemList()
    {
        this.SystemNames = new List<string>
        {
            "",
            "CRM",
            "NAMCAS",
            "ADAM",
            "RMDS",
            "CDRS",
            "管理会計",
            "国内顧問料",
            "投信管理会計",
            "業務ポータル",
            "SMD"
        };
    }
    /// <summary>ご担当者のコンボボックスに表示するリスト</summary>
    private protected virtual void InitializeGotantouShaNameList()
    {
        this.GotantouShaNames = new List<string>
        {
            "大鶴",
            "岸"
        };
    }
    /// <summary>ご担当者のコンボボックスに表示するリスト</summary>
    private protected virtual void InitializeNRITantouNameList()
    {
        this.NRITantouNames = new List<string>
        {
            "杉山",
            "陸",
            "高山"
        };
    }
    /// <summary>ご依頼部署名のコンボボックスに表示するリスト</summary>
    private protected virtual void InitializeGoiraiBushoNameList()
    {
        this.GoiraiBushoNames = new List<string>
        {
            "IT戦略部",
            "財務部",
            "CS1部",
            "CS2部",
            "DM部"
        };
    }
    private protected virtual void InitializeBunruiNameList()
    {
        // 分類の初期化
        this.BunruiNames = new List<string>
        {
            "問い合わせ",
            "作業依頼",
            "障害対応",
            "調査"
        };
    }
    #endregion
    /// <summary>
    /// 
    /// </summary>
    private void SetKaishibi()
    {
        // 今日を取得
        DateTime today = DateTime.Today;
        DateTime fromDate = DateTime.Today;
        DateTime toDate = DateTime.Today;
        LogWriter.WriteLog("Debug", "Today:" + DateTime.Today.ToString());
        LogWriter.WriteLog("Debug", "TodayMonth:" + DateTime.Today.Month.ToString());
        LogWriter.WriteLog("Debug", "TodayDay:" + DateTime.Today.Day.ToString());
        // 今日が20日以前か判定
        if (today.Day < 20)
        {
            fromDate = new DateTime(today.Year, today.AddMonths(-1).Month, 21);
            toDate = new DateTime(today.Year, today.Month, 20);
        }
        else
        {
            fromDate = new DateTime(today.Year, today.Month, 21);
            toDate = new DateTime(today.Year, today.AddMonths(1).Month, 20);
        }
        this.KaishibiFrom = fromDate;
        this.KaishibiTo = toDate;
        LogWriter.WriteLog("Debug", "kaishiDateFrom.Date:" + this.KaishibiFrom.ToString());
        LogWriter.WriteLog("Debug", "kaishiDateTo.Date:" + this.KaishibiTo.ToString());
    }


    public virtual void SearchNamTicketsAndSetResultToGrid(
        //string kaishiDateFromValue,
        //string kaishiDateToValue,
        DateTime? kaishiDateFromValue,
        DateTime? kaishiDateToValue,
        string systemGroupValue,
        string systemNameValue,
        string gotantoushaValue,
        string kihyoushaValue,
        string nriTantouValue,
        string keywordValue)
    {
        LogWriter.WriteLog("Debug", "SearchNamTicketsAndSetResultToGrid ##### 開始 #####");
        try 
        {
            // 
            List<NamTicketModel> ticketList = new List<NamTicketModel>();
            // 取得
            List<NamTicket>? namTckets = this.accessor.RetrieveNamTickets(
                kaishiDateFromValue,
                kaishiDateToValue,
                systemGroupValue,
                systemNameValue,
                gotantoushaValue,
                kihyoushaValue,
                nriTantouValue,
                keywordValue);
            LogWriter.WriteLog("Debug", "namTckets件数:" + namTckets.Count);
            // 全権繰り返し
            foreach(NamTicket ticket in namTckets) {
                // VM生成
                NamTicketModel viewModel = new NamTicketModel(ticket);
                // Listに追加
                ticketList.Add(viewModel);
            }
            this.NamTicketVMs = ticketList;

        }
        catch (Exception ex)
        {
            LogWriter.WriteLog("Debug", "例外発生！" + ex.StackTrace);
        }
        LogWriter.WriteLog("Debug", "SearchNamTicketsAndSetResultToGrid ##### 終了 #####");
    }
    /*
    /// <summary>
    /// NamTicketテーブルからデータを取得し、NamTicketVMsプロパティで取得できるようにする。
    /// </summary>
    public void xxx()
    {
        LogWriter.WriteLog("Debug", "xxx 開始");
        //this.win.GotantoushaCombobox.
        //LogWriter.WriteLog("Debug", "MainWindowViewModel コンストラクタ");
        //IsBusy  = true;
        try 
        {
            // 
            this.namTicketVMs = new List<NamTicketModel>();
            // 取得
            List<NamTicket>? result = this.accessor.GetNamTickets();
            // 全権繰り返し
            foreach(NamTicket record in result) {
                // VM生成
                NamTicketModel viewModel = new NamTicketModel(record);
                // Listに追加
                this.namTicketVMs.Add(viewModel);
            }
        }
        catch (Exception ex)
        {
            LogWriter.WriteLog("Debug", "例外発生！" + ex.StackTrace);
        }
        LogWriter.WriteLog("Debug", "xxx 終了 this.namTicketVMs.Count:" + this.namTicketVMs.Count );      
    }
    */

    public List<string> ValidateNamTicket(NamTicketModel ticket)
    {
        List<string> errorList = new List<string>();
        int count = this.accessor.GetRecordCountWithTicketCode(ticket.TicketCode);
        if (count == 0)
        {
            // OK
        }
        else
        {
            // NG
        }

        return errorList;
    }

    /// <summary>
    /// 取得したNamTicketを保存する。
    /// </summary>
    public void OnSaveChanges(NamTicket targetTicket)
    {
        try
        {
            LogWriter.WriteLog("Debug", "OnSaveChanges ##### START #####");
            // チケットの変更を保存
            this.accessor.SaveChanges(targetTicket);
            LogWriter.WriteLog("Debug", "OnSaveChanges ##### END #####");
        }
        catch (Exception e)
        {
            //
            LogWriter.WriteLog("Debug", "OnSaveChangesのSaveChangesで例外発生：" + e.Message);
        }
    }

    /// <summary>
    /// チケットコード変更前のレコードを削除し、チケットコード変更後のレコードを追加する。
    /// </summary>
    /// <param name="target">処理対象のNamTicketModel</param>
    public void DeleteAndInsert(NamTicketModel target)
    {
        try
        {
            // チケットコード変更前のチケットを取得
            NamTicket? oldTicket = target.GetOriginalNamTicket();
            // チケットコード変更前のチケットを削除
            this.accessor.DeleteRecord(oldTicket);
        }
        catch (Exception e)
        {
            //
            LogWriter.WriteLog("Debug", "DeleteAndInsertのDeleteで例外発生：" + e.Message);
        }

        try
        {
            // チケットコード変更後のチケットを取得
            NamTicket newTicket = target.GetNamTicket();
            // チケットコード変更後のチケットを追加
            this.accessor.AddRecord(newTicket);
        }
        catch (Exception e)
        {
            //
            LogWriter.WriteLog("Debug", "DeleteAndInsertのAddで例外発生：" + e.Message);
        }
    }
}