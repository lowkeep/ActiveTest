namespace IjikanriDBEditor.Entiry;
    
/// <summary>
/// NamTicketテーブルへアクセスするためのアクセッサー。
/// </summary>
public class NamTicketAccessor : IDisposable
{
    /// <summary>
    /// DBコンテキスト。
    /// </summary>
    private IjikanriContext context;
    /// <summary>
    /// コンストラクタ。
    /// DBコンテキストのインスタンスを設定する。
    /// </summary>
    public NamTicketAccessor() 
    {
        // DBコンテキストのインスタンス化
        this.context = new IjikanriContext();
    }

    /// <summary>
    /// 破棄処理。
    /// DBコンテキストの破棄を呼び出す。
    /// </summary>
    public void Dispose()
    {
        LogWriter.WriteLog("Debug", "Dispose");
        // DBコンテキストの解放
        this.context.Dispose();
    }

    /*
    /// <summary>
    /// NamTicketテーブルから、レコードを取得しListに格納して返却する。
    /// </summary>
    /// <returns>
    /// 取得したレコードを格納したList。
    /// </returns>
    public List<NamTicket>? GetNamTickets() 
    {
        // ログレベル単位で出力
        LogWriter.WriteLog("Debug", "GetNamTickets START");
        LogWriter.WriteLog("Debug", Environment.CurrentDirectory);
        //
        var exp = new List<Tuple<string, object, Type, LinqExpression>>();
        var j1 = new Tuple<string, object, Type, LinqExpression>("GoriraiBusho", "IT戦略部", typeof(string), LinqExpression.And);
        //var j2 = new Tuple<string, object, Type, LinqExpression>("SystemMei", "NAMCAS", typeof(string), LinqExpression.And);
        exp.Add(j1);
        //exp.Add(j2);

        List<NamTicket>? result = 
        this.context.NamTicket
            .DynamicWhere(exp)
            .ToList();
        LogWriter.WriteLog("Debug", "GetNamTickets END result.Count:" + result.Count);
        return result;
        
        //return this.context.NamTicket
        //    .DynamicWhere(exp)
        //    .ToList();
        
    }
    */
    /// <summary>NamTicketテーブルから条件を指定して抽出し、Listに格納して返却する。
    /// 抽出条件に使用できるのは、開始日From、To、システム名、検索キーワード。
    /// 開始日はFromからToの間（一致も含む）、システム名は一致するもの、
    /// 検索キーワードは件名と概要から 検索キーワードを含むものを
    /// すべての項目の条件が一致するレコードを抽出し返却する。
    /// </summary>
    /// <param name="kaishiDateFromValue">開始日From</param>
    /// <param name="kaishiDateToValue">開始日To</param>
    /// <param name="systemGroupValue">システムグループ</param>
    /// <param name="systemNameValue">システム名</param>
    /// <param name="gotantoushaValue">ご担当者</param>
    /// <param name="kihyoushaValue">起票者</param>
    /// <param name="nriTantouValue">NRI担当</param>
    /// <param name="keywordValue">検索キーワード</param>
    /// <returns>抽出条件にあったNamTicketを格納したList</returns>
    public List<NamTicket>? RetrieveNamTickets(
        DateTime? kaishiDateFromValue,
        DateTime? kaishiDateToValue,
        string? systemGroupValue,
        string? systemNameValue,
        string? gotantoushaValue,
        string? kihyoushaValue,
        string? nriTantouValue,
        string? keywordValue)
    {
        //List<NamTicket>? result = this.context.NamTicket
            //.Where(ticket => ticket.KaishiBi >=  kaishiDateFromValue && ticket.KaishiBi <=  kaishiDateToValue)
            //.ToList();
        //List<NamTicket>? result = 
        // 開始日は空になることはないので、開始日の抽出条件を設定
        var rows = this.context.NamTicket
            .Where(ticket => ticket.KaishiBi >=  kaishiDateFromValue && ticket.KaishiBi <=  kaishiDateToValue);
        
        // 抽出条件としてシステム名が設定されたか判定
        if (string.IsNullOrEmpty(systemNameValue) == false)
        {
            // 設定されている場合、システム名を抽出条件に追加
            rows = rows.Where(ticket => ticket.SystemMei == systemNameValue);
        }
        
        // 抽出条件として起票者が設定されたか判定
        if (string.IsNullOrEmpty(kihyoushaValue) == false)
        {
            // 設定されている場合、起票者を抽出条件に追加
            rows = rows.Where(ticket => ticket.KihyoSha == kihyoushaValue);
        }
        
        // 検索キーワードが抽出条件として設定されたか判定
        if (string.IsNullOrEmpty(keywordValue) == false)
        {
            // 設定されている場合、件名と概要が検索キーワードを含むかを抽出条件に追加
            rows = rows.Where(ticket => ticket.Kenmei.Contains(keywordValue) || ticket.Gaiyo.Contains(keywordValue));
        }
        
        // 抽出を実行して結果のリストを取得
        List<NamTicket>? result = rows.ToList();
        return result;
    }
    
    /*
    public virtual List<NamTicket>? GetNamTickets(
        string? kaishiDateFromValue,
        string? kaishiDateToValue,
        string? systemGroupValue,
        string? systemNameValue,
        string? gotantoushaValue,
        string? kihyoushaValue,
        string? nriTantouValue,
        string? keywordValue)
    {
        // ログレベル単位で出力
        LogWriter.WriteLog("Debug", "GetNamTickets START");
        LogWriter.WriteLog("Debug", Environment.CurrentDirectory);
        //
        List<Tuple<string, object, Type, LinqExpression>> exp = new List<Tuple<string, object, Type, LinqExpression>>();
        //
        Tuple<string, object, Type, LinqExpression> condition = null;
        // システム名
        if (string.IsNullOrEmpty(systemNameValue) == false)
        {
            condition = this.CreateCondtion("SystemMei",systemNameValue,LinqExpression.And);
            exp.Add(condition);
            LogWriter.WriteLog("Debug", "検索条件追加 システム名=" + systemNameValue);
        }
        // ご担当者
        if (string.IsNullOrEmpty(gotantoushaValue) == false)
        {
            condition = this.CreateCondtion("GotantouSha",gotantoushaValue,LinqExpression.And);
            exp.Add(condition);
            LogWriter.WriteLog("Debug", "検索条件追加 ご担当者=" + gotantoushaValue);
        }
        // 起票者
        if (string.IsNullOrEmpty(kihyoushaValue) == false)
        {
            condition = this.CreateCondtion("KihyoSha",kihyoushaValue,LinqExpression.And);
            exp.Add(condition);
            LogWriter.WriteLog("Debug", "検索条件追加 起票者=" + kihyoushaValue);
        }
        
        //var j1 = new Tuple<string, object, Type, LinqExpression>("GoriraiBusho", "IT戦略部", typeof(string), LinqExpression.And);
        //var j2 = new Tuple<string, object, Type, LinqExpression>("SystemMei", "NAMCAS", typeof(string), LinqExpression.And);
        //exp.Add(j1);
        //exp.Add(j2);

        List<NamTicket>? result = 
        this.context.NamTicket
            .DynamicWhere(exp)
            .ToList();
        LogWriter.WriteLog("Debug", "GetNamTickets END result.Count:" + result.Count);
        return result;
        //
        //return this.context.NamTicket
        //    .DynamicWhere(exp)
        //    .ToList();
        //
    }
    */

    
    private Tuple<string, object, Type, LinqExpression> CreateCondtion(string columnName, string value, LinqExpression expression)
    {
        Tuple<string, object, Type, LinqExpression> condition;
        condition = new Tuple<string, object, Type, LinqExpression>(columnName, value, typeof(string), expression);
        return condition;
    }


    public int GetRecordCountWithTicketCode(string targetTicketCode) 
    {
        int count = this.context.NamTicket.Count(x => x.TicketCode == targetTicketCode);
        return count;
    }


    /// <summary>
    /// DBに変更を反映させる。
    /// DBコンテキストのSaveChangesメソッドを呼び出す。
    /// </summary>
    public void SaveChanges(NamTicket target)
    {
        string state = (this.context.Entry(target).State).ToString();
        LogWriter.WriteLog("DEBUG", "SaveChanges ##### START ##### TicketCode:" + target.TicketCode + " State:" + state);
        this.context.SaveChanges();
        LogWriter.WriteLog("DEBUG", "SaveChanges ##### END #####");
    }

    public virtual void DeleteRecord(NamTicket target)
    {
        //IList<NamTicket> arg = (IList<NamTicket>)targets;
        //foreach (NamTicket SelectedItem in arg) {
            //object item = SelectedItem;
            LogWriter.WriteLog("Debug","削除対象：" + target.TicketCode);
            this.context.Remove(target);
            this.context.SaveChanges();
            LogWriter.WriteLog("Debug","削除完了：" + target.TicketCode);
        //}
    }
    public virtual void AddRecord(NamTicket target)
    {
        LogWriter.WriteLog("Debug","追加対象：" + target.TicketCode);
        this.context.NamTicket.Add(target);
        this.context.SaveChanges();
        LogWriter.WriteLog("Debug","追加完了：" + target.TicketCode);
    }


}