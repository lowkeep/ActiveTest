using Microsoft.EntityFrameworkCore;

namespace IjikanriDBEditor.Entiry;

public class IjikanriContext:DbContext
{
    public DbSet<NamTicket>? NamTicket{get;set;} //このプロパティ名がテーブル名と一致してないとダメ

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseMySQL(@"server=localhost;database=Ijikanri;userid=root;password=rootroot;sslmode=none;allowPublicKeyRetrieval=true;");
    }
}
