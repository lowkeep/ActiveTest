using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace IjikanriDBEditor.Entiry;
//INotifyPropertyChanged
/*
public class NamTicket : INotifyPropertyChanged
*/
public class NamTicket
{
    #region NamTicketテーブルの定義
    private string ticketCode;
    [Key]
    [Column("ticket_code", TypeName = "varchar(50)")]
    public string TicketCode {get; set;}


    [Column("kaishi_bi", TypeName = "date")]
    public DateTime KaishiBi {get; set;}

    [Column("goirai_busho", TypeName = "varchar(50)")]
    public string GoriraiBusho {get; set;}

    [Column("gotanto_sha", TypeName = "varchar(50)")]
    public string GotantouSha {get; set;}

    [Column("system_mei", TypeName = "varchar(50)")]
    public string SystemMei {get; set;}

    [Column("bunrui", TypeName = "varchar(50)")]
    public string Bunrui {get; set;}

    [Column("kenmei", TypeName = "varchar(50)")]
    public string Kenmei {get; set;}

    [Column("gaiyo", TypeName = "text")]
    public string Gaiyo {get; set;}

    [Column("yotei_jikan", TypeName = "varchar(50)")]
    public string YoteiJikan {get; set;}

    [Column("kihyo_sha", TypeName = "varchar(50)")]
    public string KihyoSha {get; set;}

    [Column("kihyo_bi", TypeName = "date")]
    public DateTime KihyoBi {get; set;}

    [Column("moshiokuri_jiko", TypeName = "text")]
    public string MoshiokuriJiko {get; set;}

    [Column("sagyo_bi", TypeName = "date")]
    public DateTime SagyoBi {get; set;}

    [Column("jokyo", TypeName = "varchar(50)")]
    public string Jokyo {get; set;}

    [Column("tanto_1", TypeName = "varchar(50)")]
    public string Tanto1 {get; set;}

    [Column("tanto_2", TypeName = "varchar(50)")]
    public string Tanto2 {get; set;}
    #endregion NamTicketテーブルの定義

    public NamTicket() 
    {
        // ロガーのインスタンスの取得
        LogWriter.WriteLog("Debug","コンストラクタ");
        TicketCode = "";
        KaishiBi = new DateTime(2023,12,31);
        GoriraiBusho = "";
        GotantouSha = "";
        SystemMei = "";
        Bunrui = "";
        Kenmei = "";
        Gaiyo = "";
        YoteiJikan = "";
        KihyoSha = "";
        KihyoBi = new DateTime(1000,1,1);
        MoshiokuriJiko = "";
        SagyoBi = new DateTime(1000,1,1);
        Jokyo = "";
        Tanto1 = "";
        Tanto2 = "";
    }

    //public event EventHandler<DataErrorsChangedEventArgs>? ErrorsChanged;
    //INotifyPropertyChanged
    /*
    public event PropertyChangedEventHandler? PropertyChanged;
    protected virtual void OnPropertyChanged(PropertyChangedEventArgs e)  
    {  
        PropertyChanged?.Invoke(this, e);  
       // PreDrawEvent?.Invoke(this, e);  
    }  
    //protected virtual void OnShapeChanged(DataErrorsChangedEventArgs e)  
    //{  
        //((INotifyDataErrorInfo)this).ErrorsChanged?.Invoke(this, e);  
        //PreDrawEvent?.Invoke(this, e);  
    //}  
    */
    public override bool Equals(object? target)
    {
        if (target == null || this.GetType() != target.GetType())
        {
            return false;
        }
        // TicketCodeで判定
        return (this.TicketCode == ((NamTicket)target).TicketCode);
    }
    public override int GetHashCode()
    {
        // 匿名クラスのハッシュ値を返す
        return this.TicketCode.GetHashCode();
    }

    public NamTicket GetClone()
    {
        NamTicket clone = new NamTicket();
        clone.TicketCode = this.TicketCode;
        clone.KaishiBi = this.KaishiBi;
        clone.GoriraiBusho = this.GoriraiBusho;
        clone.GotantouSha = this.GotantouSha;
        clone.SystemMei = this.SystemMei;
        clone.Bunrui = this.Bunrui;
        clone.Kenmei = this.Kenmei;
        clone.Gaiyo = this.Gaiyo;
        clone.YoteiJikan = this.YoteiJikan;
        clone.KihyoSha = this.KihyoSha;
        clone.KihyoBi = this.KihyoBi;
        clone.MoshiokuriJiko = this.MoshiokuriJiko;
        clone.SagyoBi = this.SagyoBi;
        clone.Jokyo = this.Jokyo;
        clone.Tanto1 = this.Tanto1;
        clone.Tanto2 = this.Tanto2;
        return clone;
    }
 
}