public interface ISystemGroupNamesBuilder
{
        public List<string> GetSystemGroupNamesList()
        {
            return new List<string>
            {
                "投信周辺",
                "顧問周辺",
                "SBA"
            };
        }
}