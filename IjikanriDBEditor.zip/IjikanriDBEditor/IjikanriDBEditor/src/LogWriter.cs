using System.Runtime.CompilerServices;
using log4net;
using log4net.Appender;
using log4net.Layout;
using log4net.Repository.Hierarchy;
namespace IjikanriDBEditor;
public class LogWriter
{
    /// <summary>
    /// ログ出力に使用するロガー。
    /// </summary>
    private static ILog logger = LogManager.GetLogger(typeof(LogWriter));
    
    static LogWriter()
    {
            // ログマネージャーを設定する。
            var repository = LogManager.GetRepository();
            // ログ設定を可否
            repository.Configured = true;
            // ファイルログパターンを設定
            var rollingAppender = new RollingFileAppender();
            // ファイルログモジュール名設定
            rollingAppender.Name = "RollingFile";
            // システムが起動する時に既存ファイルで内容を続けて追加するか？新しく作成するか？
            // trueなら追加する。
            rollingAppender.AppendToFile = true;
            // 新しいファイルで切り替える時に既存のログファイルにつけるファイル名パターン 例) test.log-2020-04-08
            rollingAppender.DatePattern = "-yyyy-MM-dd";
            // ログファイル設定（環境変数TEMPにLog.logで出力）
            string? TempPath = Environment.GetEnvironmentVariable("temp");
            rollingAppender.File = Path.Combine(TempPath == null ? @"C:\" : TempPath, "IjikanriDBEditor.log");
            // ファイルの単位は日付かサイズか？　- 今は日付単位で設定した。
            rollingAppender.RollingStyle = RollingFileAppender.RollingMode.Date;
            // ログパターン
            rollingAppender.Layout = new PatternLayout("%d [%t] %-5p - %m%n");
            // ログマネージャーをAppender登録が可能ようにHierarchyタイプにキャスターする。
            var hierarchy = (Hierarchy)repository;
            // Appenderを登録する。
            hierarchy.Root.AddAppender(rollingAppender);
            // ファイルログを稼働
            rollingAppender.ActivateOptions();
            // ログ出力設定がAllならすべて出力する。その以外はログレベル別で出力する。最下レベルはFatalでFatal設定すればFatalログしか出力しないこと。
            hierarchy.Root.Level = log4net.Core.Level.All;
    }

    public static void WriteLog(string logType, string message,
        [CallerFilePathAttribute] string fileNameFullPath = "",
        [CallerMemberName] string memberName = "",
        [CallerLineNumber] int sourceLineNumber = 0)
    {
        string fileName = "";
        if  (string.IsNullOrEmpty(fileNameFullPath) == false)
        {
            fileName = Path.GetFileName(fileNameFullPath);
        }
        string logBody = "Filename:" + fileName + " Line:" + sourceLineNumber + " Method:" + memberName + " : " + message;
        //サンプルコード1
        switch( logType.ToLower() )
        {
            case "fatal":
                LogWriter.logger.Fatal(logBody);
                break;
            case "error":
                LogWriter.logger.Error(logBody);
                break;
            case "warn":
                LogWriter.logger.Warn(logBody);
                break;
            case "info":
                LogWriter.logger.Info(logBody);
                break;
            default:
                    LogWriter.logger.Debug(logBody);
                    break;
        }
    }
}
