using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;

namespace IjikanriDBEditor;
public sealed partial class TicketDetailPage : Page
{
    private TicketSearchPage? searchPage;
    public TicketSearchPage? SearchPage{
        get => this.searchPage;
        set => this.searchPage = value;
    }
    private NamTicketModel? selectedTicket;
    public NamTicketModel? SelectedTicket
    {
        get => this.selectedTicket;
        set => this.selectedTicket = value;
    }
    private TicketDetailPageViewModel viewModel;
#region TicketDetailPage
    public TicketDetailPage()
    {
        LogWriter.WriteLog("Debug", "TicketDetailPage ##コンストラクタ##");
        viewModel = new();
        InitializeComponent();
    }
#endregion

#region OnNavigatedTo
    /// <summary>
    /// 画面遷移してきた時の処理。
    /// </summary>
    /// <param name="e"></param>
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        LogWriter.WriteLog("Debug", "OnNavigatedTo ##Start##");
        if (e.Parameter is TicketSearchPage && !(e.Parameter==null))
        {
            this.searchPage = (TicketSearchPage)e.Parameter;
            this.selectedTicket = this.searchPage.GetDataGridSelectedItem();
            this.viewModel = new TicketDetailPageViewModel(this.selectedTicket.GetNamTicket());
            // チケットコードが変更された時のために、
            LogWriter.WriteLog("Debug", "OnNavigatedTo ##END## this.searchPage.GetDataGridSelectedItem:" + this.selectedTicket.TicketCode);
        }
        base.OnNavigatedTo(e);
    }
#endregion

#region OnSaveClicked
    /// <summary>
    /// 保存ボタンクリック時の処理。
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private async void OnSaveClicked(object sender, RoutedEventArgs e)
    {
        LogWriter.WriteLog("Debug", "OnSaveClicked 開始");
        // ##### 
        if (this.HasChange() == false)
        {
            LogWriter.WriteLog("Debug", "OnSaveClicked 変更なしなので検索に戻る");
            // 保存後、検索画面に戻る
            Frame.Navigate(typeof(TicketSearchPage));
            return;
        }
        LogWriter.WriteLog("Debug", "OnSaveClicked 変更ありSetModel");
        this.SetModel();
        // #####        
        List<string> errors = this.SearchPage.ViewModel.ValidateNamTicket(this.SelectedTicket);
        // エラーがなかったか判定
        if (errors.Count == 0)
        {
            //エラーがなかった場合
            ContentDialogResult result = await this.ShowDialog("確認","この内容で更新してもよいですか？", true);
            //
            bool hasKeyChanged = this.SelectedTicket.HasTicketCodeChanged();
            LogWriter.WriteLog("Debug", "HasTicketCodeChanged:" + hasKeyChanged + " TicketCode:" + this.SelectedTicket.TicketCode);
            if (hasKeyChanged == true)
            {
                try
                {
                    this.SearchPage.ViewModel.DeleteAndInsert(this.SelectedTicket);
                }
                catch (Exception delEx)
                {
                    LogWriter.WriteLog("Debug", "例外発生:" + delEx.ToString());
                    this.ShowDialog("例外発生","チケットコード修正に伴うDeleteInsertに失敗しました。");
                }
            }
            else
            {
                try
                {
                    //this.SearchPage.ViewModel.DeleteAndInsert(this.SelectedTicket);
                    this.SearchPage.ViewModel.OnSaveChanges(this.SelectedTicket.GetNamTicket());
                }
                catch (Exception addEx)
                {
                    LogWriter.WriteLog("Debug", "例外発生:" + addEx.ToString());
                    this.ShowDialog("例外発生","更新に失敗しました。");
                }

            }
            // 保存後、検索画面に戻る
            Frame.Navigate(typeof(TicketSearchPage));
        }
        else 
        {
            // エラーがあった場合
            this.ShowDialog("エラーあり","エラー！！！！！");
        }
        
    }
 #endregion

 #region HasChange
    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    private bool HasChange()
    {
        LogWriter.WriteLog("Debug", "HasChange開始");
        // １段目
        // チケットコードに変更があったか判定
        if ( this.SelectedTicket.TicketCode.Equals(TicketCodeTextBox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "チケットコード変更あり:" + this.SelectedTicket.TicketCode + " vs " + TicketCodeTextBox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        // 開始日に変更があったか判定
        if ( ((DateTimeOffset)this.SelectedTicket.KaishiBi).Equals(KaishiDateDatePicker.Date) == false )
        {
        LogWriter.WriteLog("Debug", "開始日変更あり:" + this.SelectedTicket.KaishiBi.ToString() + " vs " + KaishiDateDatePicker.Date.ToString());
            // 変更があったらtrueを返却
            return true;
        }

        // システム名に変更があったか判定
        if ( this.SelectedTicket.SystemMei.Equals(SystemMeiCombobox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "システム名変更あり:" + this.SelectedTicket.SystemMei + " vs " + SystemMeiCombobox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        // ご依頼部署に変更があったか判定
        if ( this.SelectedTicket.GoriraiBusho.Equals(GoiraiBushoCombobox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "ご依頼部署変更あり:" + this.SelectedTicket.GoriraiBusho + " vs " + GoiraiBushoCombobox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        LogWriter.WriteLog("Debug", "ご担当者GotantoushaCombobox.Text:" + GotantoushaCombobox.Text);
        LogWriter.WriteLog("Debug", "ご担当者GotantoushaCombobox.SelectedItem:" + GotantoushaCombobox.SelectedItem);
        LogWriter.WriteLog("Debug", "ご担当者GotantoushaCombobox.SelectedValue:" + GotantoushaCombobox.SelectedValue);
        LogWriter.WriteLog("Debug", "ご担当者GotantoushaCombobox.SelectedValuePath:" + GotantoushaCombobox.SelectedValuePath);
        LogWriter.WriteLog("Debug", "ご担当者GotantoushaCombobox.SelectionBoxItem:" + GotantoushaCombobox.SelectionBoxItem);
        // ご担当者に変更があったか判定
        if ( this.SelectedTicket.GotantouSha.Equals(GotantoushaCombobox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "ご担当者変更あり:" + this.SelectedTicket.GotantouSha + " vs " + GotantoushaCombobox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        // 分類に変更があったか判定
        if ( this.SelectedTicket.Bunrui.Equals(BunruiCombobox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "分類変更あり:" + this.SelectedTicket.Bunrui + " vs " + BunruiCombobox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        // ２段目
        // 予定時間に変更があったか判定
        LogWriter.WriteLog("Debug", "予定時間 SelectedTicket.YoteiJikan:" + this.SelectedTicket.YoteiJikan);
        LogWriter.WriteLog("Debug", "予定時間 YoteijikanTextBox.Text:" + YoteijikanTextBox.Text);
        if ( this.SelectedTicket.YoteiJikan.Equals(YoteijikanTextBox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "予定時間変更あり:" + this.SelectedTicket.YoteiJikan + " vs " + YoteijikanTextBox.Text);
            // 変更があったらtrueを返却
            return true;
        }
        // 担当１に変更があったか判定
        if ( this.SelectedTicket.Tanto1.Equals(Tantou1TextBox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "担当１変更あり:" + this.SelectedTicket.Tanto1 + " vs " + Tantou1TextBox.Text);
            // 変更があったらtrueを返却
            return true;
        }
        // 担当２に変更があったか判定
        if ( this.SelectedTicket.Tanto2.Equals(Tantou2TextBox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "担当２変更あり:" + this.SelectedTicket.Tanto2 + " vs " + Tantou2TextBox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        // ３段目
        // 起票者に変更があったか判定
        if ( this.SelectedTicket.KihyoSha.Equals(KihyoShaCombobox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "起票者変更あり:" + this.SelectedTicket.KihyoSha + " vs " + KihyoShaCombobox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        // 起票日に変更があったか判定
        if ( ((DateTimeOffset)this.SelectedTicket.KihyoBi).Equals(KihyoBiDatePicker.Date) == false )
        {
        LogWriter.WriteLog("Debug", "起票日変更あり:" + this.SelectedTicket.KihyoBi.ToString() + " vs " + KihyoBiDatePicker.Date.ToString());
            // 変更があったらtrueを返却
            return true;
        }

        // 作業日に変更があったか判定
        if ( ((DateTimeOffset)this.SelectedTicket.SagyoBi).Equals(SagyoBiDatePicker.Date) == false )
        {
        LogWriter.WriteLog("Debug", "作業日変更あり:" + this.SelectedTicket.SagyoBi.ToString() + " vs " + SagyoBiDatePicker.Date.ToString());
            // 変更があったらtrueを返却
            return true;
        }
        // 状況に変更があったか判定
        if ( this.SelectedTicket.Jokyo.Equals(JokyoTextBox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "状況変更あり:" + this.SelectedTicket.Jokyo + " vs " + JokyoTextBox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        // ４段目
        // 件名に変更があったか判定
        if ( this.SelectedTicket.Kenmei.Equals(KenmeiTextBox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "件名変更あり:" + this.SelectedTicket.Kenmei + " vs " + KenmeiTextBox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        // ５段目
        // 概要に変更があったか判定
        if ( this.SelectedTicket.Gaiyo.Equals(GaiyouTextBox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "概要変更あり:" + this.SelectedTicket.Gaiyo + " vs " + GaiyouTextBox.Text);
            // 変更があったらtrueを返却
            return true;
        }

        // 申し送り事項に変更があったか判定
        if ( this.SelectedTicket.MoshiokuriJiko.Equals(MoshiokuriJikoTextBox.Text) == false )
        {
        LogWriter.WriteLog("Debug", "申し送り事項変更あり:" + this.SelectedTicket.MoshiokuriJiko + " vs " + MoshiokuriJikoTextBox.Text);
            // 変更があったらtrueを返却
            return true;
        }
        LogWriter.WriteLog("Debug", "HasChange変更なしで終了");
        return false;
    }
#endregion

#region OnBackClicked
    /// <summary>
    /// 戻るボタンクリック時の処理。
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnBackClicked(object sender, RoutedEventArgs e)
    {
        LogWriter.WriteLog("Debug", "OnBackClicked 開始");
        LogWriter.WriteLog("Debug", "SelectedTicket.SystemMei:" + this.SelectedTicket.SystemMei);
        LogWriter.WriteLog("Debug", "SelectedTicket.GoriraiBusho:" + this.SelectedTicket.GoriraiBusho);
        LogWriter.WriteLog("Debug", "SystemMeiCombobox.Text:" + SystemMeiCombobox.Text);
        LogWriter.WriteLog("Debug", "GoiraiBushoCombobox.Text:" + GoiraiBushoCombobox.Text);
        this.HasChange();
        Frame.Navigate(typeof(TicketSearchPage));
   }
#endregion

#region SetModel
    private void SetModel() 
    {
        // チケットコード
        if ( this.SelectedTicket.TicketCode.Equals(TicketCodeTextBox.Text) == false )
        {
            this.SelectedTicket.TicketCode = TicketCodeTextBox.Text;
        }
        //DateTimeOffset dto = DateTimeOffset.MaxValue;
        // 開始日に変更があったか判定
        if ( ((DateTimeOffset)this.SelectedTicket.KaishiBi).Equals(KaishiDateDatePicker.Date) == false )
        {
            //this.SelectedTicket.KaishiBi = ((System.DateTimeOffset)KaishiDateDatePicker.Date).LocalDateTime;
            if (KaishiDateDatePicker.Date.HasValue)
            {
                this.SelectedTicket.KaishiBi = KaishiDateDatePicker.Date.Value.LocalDateTime;
            }
            else
            {

            }
        }
        // システム名に変更があったか判定
        if ( this.SelectedTicket.SystemMei.Equals(SystemMeiCombobox.Text) == false )
        {
            this.SelectedTicket.SystemMei = SystemMeiCombobox.Text;
        }
        // ご依頼部署に変更があったか判定
        if ( this.SelectedTicket.GoriraiBusho.Equals(GoiraiBushoCombobox.Text) == false )
        {
            this.SelectedTicket.GoriraiBusho = GoiraiBushoCombobox.Text;
        }
        // ご担当者に変更があったか判定
        if ( this.SelectedTicket.GotantouSha.Equals(GotantoushaCombobox.Text) == false )
        {
            this.SelectedTicket.GotantouSha = GotantoushaCombobox.Text;
        }
        // 分類に変更があったか判定
        if ( this.SelectedTicket.Bunrui.Equals(BunruiCombobox.Text) == false )
        {
            this.SelectedTicket.Bunrui = BunruiCombobox.Text;
        }
        // ２段目
        // 予定時間に変更があったか判定
        if ( this.SelectedTicket.YoteiJikan.Equals(YoteijikanTextBox.Text) == false )
        {
            this.SelectedTicket.YoteiJikan = YoteijikanTextBox.Text;
        }
        // 担当１に変更があったか判定
        if ( this.SelectedTicket.Tanto1.Equals(Tantou1TextBox.Text) == false )
        {
            this.SelectedTicket.Tanto1 = Tantou1TextBox.Text;
        }
        // 担当２に変更があったか判定
        if ( this.SelectedTicket.Tanto2.Equals(Tantou2TextBox.Text) == false )
        {
            this.SelectedTicket.Tanto2 = Tantou2TextBox.Text;
        }
        // ３段目
        // 起票者に変更があったか判定
        if ( this.SelectedTicket.KihyoSha.Equals(KihyoShaCombobox.Text) == false )
        {
            this.SelectedTicket.KihyoSha = KihyoShaCombobox.Text;
        }
        // 起票日に変更があったか判定
        if ( ((DateTimeOffset)this.SelectedTicket.KihyoBi).Equals(KihyoBiDatePicker.Date) == false )
        {
            this.SelectedTicket.KihyoBi = ((System.DateTimeOffset)KihyoBiDatePicker.Date).LocalDateTime;
        }
        // 作業日に変更があったか判定
        if ( ((DateTimeOffset)this.SelectedTicket.SagyoBi).Equals(SagyoBiDatePicker.Date) == false )
        {
            this.SelectedTicket.SagyoBi = ((System.DateTimeOffset)SagyoBiDatePicker.Date).LocalDateTime;
        }
        // 状況に変更があったか判定
        if ( this.SelectedTicket.Jokyo.Equals(JokyoTextBox.Text) == false )
        {
            this.SelectedTicket.Jokyo = JokyoTextBox.Text;
        }
        // ４段目
        // 件名に変更があったか判定
        if ( this.SelectedTicket.Kenmei.Equals(KenmeiTextBox.Text) == false )
        {
            this.SelectedTicket.Kenmei = KenmeiTextBox.Text;
        }
        // ５段目
        // 概要に変更があったか判定
        if ( this.SelectedTicket.Gaiyo.Equals(GaiyouTextBox.Text) == false )
        {
            this.SelectedTicket.Gaiyo = GaiyouTextBox.Text;
        }
        // 申し送り事項に変更があったか判定
        if ( this.SelectedTicket.MoshiokuriJiko.Equals(MoshiokuriJikoTextBox.Text) == false )
        {
            this.SelectedTicket.MoshiokuriJiko = MoshiokuriJikoTextBox.Text;
        }
    }
#endregion

#region void ShowDialog
   /// <summary>ダイアログボックスを表示する。</summary>
   /// <param name="Title">ダイアログボックスのタイトル</param>
   /// <param name="Content">表示する内容</param>
   private async void ShowDialog(string Title, string Content)
   {
        ContentDialog contentDialog = new()
        {
            Title = Title,
            Content = Content,
            CloseButtonText = "閉じる",
                // ここの設定が必須！！
            XamlRoot = this.Content.XamlRoot,
        };
        await contentDialog.ShowAsync();
    }
#endregion

#region Task ShowDialog
    /// <summary>
    /// ダイアログボックスを表示する。
    /// </summary>
    /// <param name="Title"></param>
    /// <param name="Content"></param> <summary>
    /// <returns></returns>
    private async Task<ContentDialogResult> ShowDialog(string Title, string Content, bool isHai)
    {
        LogWriter.WriteLog("Debug", "ShowDialog 開始");            
        ContentDialog contentDialog = new ContentDialog()
        {
            Title = Title,
            Content = Content,
            CloseButtonText = "閉じる",
                // ここの設定が必須！！
            XamlRoot = this.Content.XamlRoot,
        };
        if (isHai == true)
        {
            contentDialog.PrimaryButtonText = "はい";
        }
        ContentDialogResult result = await contentDialog.ShowAsync();
        return result;
    }
#endregion
}