// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

using System.Collections;
using CommunityToolkit.WinUI.UI.Controls;
using IjikanriDBEditor.Entiry;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;

namespace IjikanriDBEditor;
/// <summary>
/// An empty window that can be used on its own or navigated to within a Frame.
/// </summary>
public sealed partial class MainWindow : Window
{
    
    /// <summary>
    /// コンストラクタ。
    /// ウィンドウサイズの変更を行う。
    /// </summary>
    public MainWindow()
    {
        InitializeComponent();
        this.SetWindowSize();
    }
            /// <summary>
    /// 初期ウィンドウサイズに設定する。
    /// </summary>
    private void SetWindowSize()
    {
        IntPtr hwnd = WinRT.Interop.WindowNative.GetWindowHandle(this);
        Microsoft.UI.WindowId windowId = Microsoft.UI.Win32Interop.GetWindowIdFromWindow(hwnd);
        Microsoft.UI.Windowing.AppWindow appWindow = Microsoft.UI.Windowing.AppWindow.GetFromWindowId(windowId);
        appWindow.Resize(new Windows.Graphics.SizeInt32(1600,900));
        LogWriter.WriteLog("Debug", "SetWindowSize 終了");
    }
}