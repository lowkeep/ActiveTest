using System.Collections;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Navigation;

namespace IjikanriDBEditor;
public sealed partial class TicketSearchPage : Page
{
    private MainWindowViewModel viewModel;

    public MainWindowViewModel ViewModel
    {
        get
        {
            return viewModel;
        }
    }

    public TicketSearchPage()
    {
        LogWriter.WriteLog("Debug", "TicketSearchPage コンストラクタ開始 MainWindowViewModel");
        this.viewModel = new MainWindowViewModel();
        LogWriter.WriteLog("Debug", "TicketSearchPage コンストラクタ InitializeComponent");
        InitializeComponent();
        this.viewModel.ShowDialogFunc = ShowDialog;
        //this.SetKaishibi();
        //this.viewModel.setWindow(this);
    }
    /*
    private void SetKaishibi()
    {
        // 今日を取得
        DateTime today = DateTime.Today;
        DateTime fromDate = DateTime.Today;
        DateTime toDate = DateTime.Today;
        // 今日が20日以前か判定
        if (today.Day >= 20)
        {
            fromDate = new DateTime(today.Year, today.AddMonths(-1).Month, 21);
            toDate = new DateTime(today.Year, today.Month, 20);
        }
        else
        {
            fromDate = new DateTime(today.Year, today.Month, 21);
            toDate = new DateTime(today.Year, today.AddMonths(1).Month, 20);
        }
        this.kaishiDateFrom.Date = fromDate;
        this.kaishiDateTo.Date = toDate;
        LogWriter.WriteLog("Debug", "kaishiDateFrom.Date:" + this.kaishiDateFrom.Date.ToString());
        LogWriter.WriteLog("Debug", "kaishiDateFrom.Date:" + this.kaishiDateTo.Date.ToString());
    }
    */

    /*
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        LogWriter.WriteLog("Debug", "OnNavigatedTo");
    }
    */

    /*
    private void HyperlinkButton_Click(object sender, RoutedEventArgs e)
    {
        Frame.Navigate(typeof(TicketDetailPage));
    }
    */

    /*
    /// <summary>
    /// ウィンドウを閉じるときのイベント。
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnClosed(object sender, WindowEventArgs e)
    {
        LogWriter.WriteLog("Debug", "OnClosed");
        // アクセサの破棄
        //this.accessor.Dispose();
    }
    */

    /*
    /// <summary>
    ///  検索ボタンクリック時のイベント。
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    private void OnSearchClicked(object sender, RoutedEventArgs e)
    {
        LogWriter.WriteLog("Debug", "OnSearchClicked 開始");            
        //IsBusy  = true;
        /* ★Before
        List<NamTicket>? result = this.accessor.GetNamTickets();
        try 
        {
            WinUI3DataGrid.ItemsSource = result;
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.StackTrace);
        }
        ★Before */ /*
        //CommunityToolkit.WinUI.UI.Controls.DataGrid d = new ();
        // 開始日From
        //string? kaishiDateFromValue = null;
        DateTime? kaishiDateFromValue = null;
        if ( this.kaishiDateFrom.Date != null)
        {
            //LogWriter.WriteLog("Debug", "kaishiDateFrom:" + this.kaishiDateFrom.GetType().ToString());
            //LogWriter.WriteLog("Debug", "kaishiDateFrom.Date:" + this.kaishiDateFrom.Date.GetType().ToString());
            //LogWriter.WriteLog("Debug", "kaishiDateFrom.Date.ToString:" + this.kaishiDateFrom.Date.ToString());
            //string dateString = this.kaishiDateFrom.Date.ToString();

            //var dateArray = dateString.Split(' ')[0].Split('/');
            //LogWriter.WriteLog("Debug", "kaishiDateFrom.Date Year:" + dateArray[0]);
            //LogWriter.WriteLog("Debug", "kaishiDateFrom.Date Month:" + dateArray[1]);
            //LogWriter.WriteLog("Debug", "kaishiDateFrom.Date Day:" + dateArray[2]);
            //kaishiDateFromValue = new DateTime(int.Parse(dateArray[0]), int.Parse(dateArray[1]), int.Parse(dateArray[2]));
            //LogWriter.WriteLog("Debug", "kaishiDateFrom -> DateTime:" + kaishiDateFromValue.ToString());
            kaishiDateFromValue = this.CreateDateTime(this.kaishiDateFrom);
            


            //kaishiDateFromValue = this.kaishiDateFrom.Date.ToLocalTime();
            //kaishiDateFromValue = this.kaishiDateFrom.Date.ToString();
            //DateTimeOffset? d = null;
        }
        // 開始日To
        //string? kaishiDateToValue = null;
        DateTime? kaishiDateToValue =null;
        if (this.kaishiDateTo.Date != null)
        {
            //kaishiDateToValue = this.kaishiDateTo.Date;
            //kaishiDateToValue = this.kaishiDateTo.DateTime;
            kaishiDateToValue = this.CreateDateTime(this.kaishiDateTo);
        }
        // システムグループ
        string? systemGroupValue = null;
        if (this.SystemGroupCombobox.SelectedValue != null)
        {
            systemGroupValue = this.SystemGroupCombobox.SelectedValue.ToString();
        }
        // システム名
        string? systemNameValue = null;
        if (this.SystemNameCombobox.SelectedValue != null)
        {
            systemNameValue = this.SystemNameCombobox.SelectedValue.ToString();
        }
        // ご担当者
        string? gotantoushaValue = null;
        if (this.GotantoushaCombobox.SelectedValue != null)
        {
            gotantoushaValue = this.GotantoushaCombobox.SelectedValue.ToString();
        }
        // 起票者
        string? kihyoushaValue = null;
        if (this.KihyoushaCombobox.SelectedValue != null)
        {
            kihyoushaValue = this.KihyoushaCombobox.SelectedValue.ToString();
        }
        // NRI担当
        string? nriTantouValue = null;
        if (this.NritantouCombobox.SelectedValue != null)
        {
            nriTantouValue = this.NritantouCombobox.SelectedValue.ToString();
        }
        // 検索キーワード
        string? keywordValue = this.SearchKeywordTextBox.Text;
        //LogWriter.WriteLog("Debug", "開始日From:" + kaishiDateFromValue);
        //LogWriter.WriteLog("Debug", "開始日To:" + kaishiDateToValue);
        LogWriter.WriteLog("Debug", "システムグループ:" + systemGroupValue);
        LogWriter.WriteLog("Debug", "システム名:" + systemNameValue);
        LogWriter.WriteLog("Debug", "ご担当者:" + gotantoushaValue);
        LogWriter.WriteLog("Debug", "起票者:" + kihyoushaValue);
        LogWriter.WriteLog("Debug", "NRI担当:" + nriTantouValue);
        LogWriter.WriteLog("Debug", "検索キーワード:" + keywordValue);

        this.ViewModel.SearchNamTicketsAndSetResultToGrid(
            kaishiDateFromValue,
            kaishiDateToValue,
            systemGroupValue,
            systemNameValue,
            gotantoushaValue,
            kihyoushaValue,
            nriTantouValue,
            keywordValue);
        WinUI3DataGrid.ItemsSource = ViewModel.NamTicketVMs;
        LogWriter.WriteLog("Debug", "OnSearchClicked 終了");
        //IsBusy  = false;
    }
    */
    /*

    private DateTime CreateDateTime(CalendarDatePicker target)
    {
        // カレンダーで選択した日付の文字列を取得
        string dateString = target.Date.ToString();
        // スペース区切りで最初の要素から、/区切りで配列を取得
        var dateArray = dateString.Split(' ')[0].Split('/');
        //LogWriter.WriteLog("Debug", "kaishiDateFrom.Date Year:" + dateArray[0]);
        //LogWriter.WriteLog("Debug", "kaishiDateFrom.Date Month:" + dateArray[1]);
        //LogWriter.WriteLog("Debug", "kaishiDateFrom.Date Day:" + dateArray[2]);
        DateTime DateTimevalue = new DateTime(int.Parse(dateArray[0]), int.Parse(dateArray[1]), int.Parse(dateArray[2]));
        //LogWriter.WriteLog("Debug", "kaishiDateFrom -> DateTime:" + DateTimevalue.ToString());
        return DateTimevalue;
    }
    */
    /*
        private void ImageButton_Click(object sender, RoutedEventArgs e)
        {}
    */
        /*
        /// <summary>
        /// 更新ボタンクリック時のイベント。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        private async void OnUpdateClicked(object sender, RoutedEventArgs e)
        {
            LogWriter.WriteLog("Debug", "OnUpdateClicked 開始");            
            ContentDialogResult result = await this.ShowDialog("ボタンクリック","更新ボタンクリック！",true);
            if (result == ContentDialogResult.Primary)
            {
                //this.accessor.SaveChanges();
                this.ViewModel.OnSaveChanges();
            }
        }
        */
        /*
        /// <summary>
        /// 削除ボタンクリック時のイベント。
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        private void OnDeleteClicked(object sender, RoutedEventArgs e)
        {
            LogWriter.WriteLog("Debug", "OnDeleteClicked 開始");            
            IList  SelectedItems = WinUI3DataGrid.SelectedItems;
            //List<NamTicket>? gridSource = (List<NamTicket>?)WinUI3DataGrid.ItemsSource;

            //this.accessor.DeleteRecords( (List<NamTicket>?)SelectedItems);
            foreach (NamTicketModel SelectedItem in SelectedItems) {
                //object item = SelectedItem;
                //this.accessor.DeleteRecords(SelectedItem);
                //gridSource.Remove(SelectedItem);
            }
        }
        */

        /*
         public void DataGridCellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
         {
            LogWriter.WriteLog("Debug", "DataGridCellEditEnding ##START##");
            int i = 0;
            var ea = e.EditAction.ToString();
            var ee = e.EditingElement; 
            var val = e.EditingElement.ToString();
            string name = e.Column.Header.ToString();
            LogWriter.WriteLog("Debug", "DataGridCellEditEnding ##END## :" + ea +":" + ee + ":" + val + ":" + name);
        }
       
        public void DataGridBeginningEdit(object sender, DataGridBeginningEditEventArgs e)
        {
            LogWriter.WriteLog("Debug", "DataGridCellEditEnding ##START##");
        }
        public void DataGridContextRequested(object sender, ContextRequestedEventArgs e)
        {
            LogWriter.WriteLog("Debug", "DataGridContextRequested ##START##");
            IList  SelectedItems = WinUI3DataGrid.SelectedItems;
            string s = "";
            foreach (NamTicketModel SelectedItem in SelectedItems) {
                s = SelectedItem.TicketCode;
                //object item = SelectedItem;
                //this.accessor.DeleteRecords(SelectedItem);
                //gridSource.Remove(SelectedItem);
            }
            LogWriter.WriteLog("Debug", "DataGridContextRequested ##END## First:" + s);

        }
        */
        private void DataGridDoubleTapped(object sender, DoubleTappedRoutedEventArgs e)
        {
            LogWriter.WriteLog("Debug", "DataGridDoubleTapped ##START##");
            //IList  SelectedItems = this.GetDataGridSelectedItem();
            NamTicketModel targetTicket = this.GetDataGridSelectedItem();
            //foreach (NamTicketModel SelectedItem in SelectedItems) {
//                targetRow = SelectedItem;
  //          }
            LogWriter.WriteLog("Debug", "DataGridDoubleTapped ##Navigate##" + targetTicket.TicketCode);
            Frame.Navigate(typeof(TicketDetailPage), this);


        }
        public NamTicketModel? GetDataGridSelectedItem()
        {
            NamTicketModel item = null;
            IList  SelectedItems = WinUI3DataGrid.SelectedItems;
            foreach (NamTicketModel SelectedItem in SelectedItems) {
                item = SelectedItem;
                // 最初のレコードを対象とする
                break;
            }
            return item;
        }

        /// <summary>
        /// ダイアログボックスを表示する。
        /// </summary>
        /// <param name="Title"></param>
        /// <param name="Content"></param> <summary>
        /// <returns></returns>
        private async Task<ContentDialogResult> ShowDialog(string Title, string Content, bool isHai)
        {
            LogWriter.WriteLog("Debug", "ShowDialog 開始");            
            ContentDialog contentDialog = new ContentDialog()
            {
                Title = Title,
                Content = Content,
                CloseButtonText = "閉じる",
                 // ここの設定が必須！！
                XamlRoot = this.Content.XamlRoot,
            };
            if (isHai == true)
            {
                contentDialog.PrimaryButtonText = "はい";
            }
            ContentDialogResult result = await contentDialog.ShowAsync();
            return result;
        }
}