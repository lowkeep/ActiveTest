# TicketSearchPageクラス
## プロパティ
### 1. MainWindowViewModel  
fffff  
ffff  
### 1. iメソッド
1. public NamTicketModel? GetDataGridSelectedItem()  
  WinUI3DataGrid.SelectedItemsの最初の要素を返却する。

# TicketDetailPageクラス
| タイトル | 分類 | 内容 |
| --- | --- | --- |
| **コントロール** | | |
| | チケットコード | 種類：TextBox | 
| | | Textプロパティ-> Text="{x:Bind SelectedTicket.TicketCode, Mode=TwoWay}" |
| | 開始日 |種類：TextBox |
| | | Textプロパティ -> Text="{x:Bind SelectedTicket.TicketCode, Mode=TwoWay}" |
| **プロパティ** | | |
| | public TicketSearchPage? SearchPage| |
| | private NamTicketModel? selectedTicket | |
| | public NamTicketModel? SelectedTicket | |
| **メソッド** | | |
| | OnNavigatedTo | | 


```mermaid
flowchart RL
   %%{ init: { 'flowchart': { 'curve': 'linear' } } }%%
    A(日本株オープン):::node_A --> B(日本株マザーファンド)
    B --> C & D
    C --> E & F
    X --> B
    click A href "https://qiita.com/hirokiwa/items/841fcb749873f2847af7"
    classDef node_A fill:#00FF00,stroke:#FF22FF,stroke-width:10px;
```